#include <stdio.h>
#include <conio.h>
#define N 11
#define M 20
int obraz[N][M] = {
        { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
        { 0,0,1,1,0,1,1,1,0,0,0,0,0,0,1,1,0,0,0,0 },
        { 0,0,1,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,0,0 },
        { 0,0,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,0,0,0 },
        { 0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0 },
        { 0,0,0,0,0,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0 },
        { 0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0 },
        { 0,0,1,1,1,1,1,1,0,0,1,1,1,1,1,1,1,0,0,0 },
        { 0,0,1,1,0,1,1,1,0,0,1,1,1,1,1,1,1,0,0,0 },
        { 0,0,1,1,0,1,1,1,0,0,0,0,0,0,1,1,0,0,0,0 },
        { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 },
};
int elStr[3][3] = {
        { 1,1,1 },
        { 1,1,1 },
        { 1,1,1 },
};

int elementStr[3][3] = {0,0,0,1,1,0,1,1,1};

void wyswietlObraz(int obraz[N][M])
{
    int i,j;
    printf("%c",0xDA);
    for(j=0;j<M;j++) printf("%c",0xC4);
    printf("%c\n",0xBF);

    for(i=0;i<N;i++) {
        printf("%c",0xB3);
        for(j=0;j<M;j++)
            printf("%c",(obraz[i][j]==1) ? 0xDB : 0xB0);
        printf("%c\n",0xB3);
    }

    printf("%c",0xC0);
    for(j=0;j<M;j++) printf("%c",0xC4);
    printf("%c\n",0xD9);
}
 // erozja
 
void erozja(int obraz[N][M], int obraz2[N][M], int elStr[3][3]){

    
    for(int j=1; j<M-1; j++){
        for(int i=1; i<N-1; i++){
            if((obraz[i-1][j] == elStr[0][1]) && (obraz[i][j-1]==elStr[1][0]) && (obraz[i][j] == elStr[1][1]) &&
                    (obraz[i][j+1] == elStr[1][2]) && (obraz[i+1][j] == elStr[2][1])){
                obraz2[i][j] = 1;
            }
            else obraz2[i][j] = 0;
        }
    }


}
//dylatacja
void dylatacja(int obraz2[N][M], int obraz3[N][M], int elStr[3][3]){
    

    for(int j=1; j<M-1; j++){
        for(int i=1; i<N-1; i++){
            if((obraz2[i-1][j] == elStr[0][1]) || (obraz2[i][j-1]==elStr[1][0]) || (obraz2[i][j] == elStr[1][1]) ||
               (obraz2[i][j+1] == elStr[1][2]) || (obraz2[i+1][j] == elStr[2][1])){
                obraz3[i][j] = 1;
            }
            else obraz3[i][j] = 0;
        }
    }

}




void otwarcie(int obraz_otwarcie[N][M], int obraz2[N][M]){

    
    dylatacja(obraz2,obraz_otwarcie,elStr);

    printf("Obraz po operacji otwarcia:\n");
    wyswietlObraz(obraz_otwarcie);
}





void zamkniecie(int obraz_zamkniecie[N][M], int obraz3[N][M]){

// erozja na dylatowanym obrazie
    erozja(obraz3,obraz_zamkniecie,elStr);

    printf("Obraz po operacji zamkniecia:\n");
    wyswietlObraz(obraz_zamkniecie);

}

void dopelnienie(int dop[N][M]){

    for(int i=0; i<N; i++){
        for(int j = 0; j<M; j++){
            if(obraz[i][j] == 1) dop[i][j] = 0;
            if(obraz[i][j] == 0) dop[i][j] = 1;
        }
    }

    printf("Dopelnienie obrazu oryginalnego:\n");
    wyswietlObraz(dop);

}

void suma(int dop[N][M], int suma[N][M]){

    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            if(obraz[i][j] == 1 || dop[i][j] == 1) suma[i][j] = 1;
            else suma[i][j] = 0;
        }
    }

    printf("Suma dwoch obrazow:\n");
           

    wyswietlObraz(suma);

}

void iloczyn(int suma[N][M]){
    int iloczyn[N][M] = {0};
    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            if(obraz[i][j] == 1 && suma[i][j] == 1) iloczyn[i][j] = 1;
            else iloczyn[i][j] = 0;
        }
    }

    printf("Obliczanie iloczynu \nObraz oryginalny (iloczyn) suma = obraz oryginalny:\n");
    wyswietlObraz(iloczyn);
}

void roznica(int obraz2[N][M]){
   int roznica[N][M] = {0};

    for(int i=0; i<N; i++){
        for(int j=0; j<M; j++){
            if(obraz[i][j] == 1 && obraz2[i][j] == 1) roznica[i][j] = 0;
            else roznica[i][j] = obraz[i][j];
        }
    }
    printf("Obliczanie roznicy odejmowanie obrazu oryginalnego od jego erozji:\n");
    wyswietlObraz(roznica);
}

int main()
{
    int obraz2[N][M] = {0};
    int obraz3[N][M] = {0};
    int obraz_otwarcie[N][M] = {0};
    int obraz_zamkniecie[N][M] = {0};
    int dop[N][M] = {0};
    int sum[N][M] = {0};
    int zad5[N][M] = {0};
    int zad5_2[N][M] = {0};

    printf("\nObraz oryginalny:\n");

    wyswietlObraz(obraz);

    erozja(obraz, obraz2, elStr);
    printf("\nObraz oryginalny po erozji:\n");
    wyswietlObraz(obraz2);

    dylatacja(obraz,obraz3, elStr);
    printf("\nObraz oryginalny po dylatacji:\n");
    wyswietlObraz(obraz3);

    otwarcie(obraz_otwarcie, obraz2);

    zamkniecie(obraz_zamkniecie, obraz3);

    dopelnienie(dop);

    suma(dop,sum);

    iloczyn(sum);

    roznica(obraz2);

    printf("\nErozja obrazu oryginalnego ze zmienionym elementem strukturujacym:\n");
    erozja(obraz,zad5,elementStr);
    wyswietlObraz(zad5);

    printf("\nDylatacja obrazu oryginalnego ze zmienionym elementem strukturujacym:\n");
    dylatacja(obraz,zad5_2,elementStr);
    wyswietlObraz(zad5_2);

    getch();
    return 0;
}
