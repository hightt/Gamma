@extends('layout')

@section('content')

<div class="row justify-content-center">
    <div class="col-md-4 col-sm-12 mt-5 p-4 bg-light border border-primary">
        <form action="/updateComment/{{$comment->id}}" method="POST">
            @csrf
            <a class="btn" href="/{{$comment->post()->value('id')}}" role="button">
                <img src="/img/arrow.png" class="navIcon" href="/">
            </a>
            <h3 class="text-center mb-2">Edytuj:</h3>
            <div class="form-group ">
                <label>Treść posta: </label>
                <textarea class="form-control" name="body" rows="7"
                    placeholder="Tutaj wpisz zawartość posta">{{$comment->body}}</textarea>
                @error('body')
                <span class="error">{{$errors->first('body')}}</span>
                @enderror
            </div>
            <input type="hidden" name="post_id" value="  {{$comment->post()->value('id')}}">
            <input type="hidden" name="user_id" value="{{$comment->user_id}}">
            <button type="submit" name="submit" class="btn btn-success float-center">Edytuj</button>
            <hr>
        </form>
        <a class="btn btn-secondary float-right" href="/" role="button">Zamknij</a>
    </div>
</div>

@endsection
