@extends('layout')
@section('content')

<div class="container-fluid top">
    <div class="row justify-content-center mt-5">
        <div class="col-12 word-wrap">
            <h2>{{$post->title}}</h2>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-6 col-sm-4">
            <a class="btn" href="/" role="button">
                <img src="../img/arrow.png" class="navIcon" href="/">
            </a>
        </div>

        <div class="col-xl-6 col-sm-8">
            @can('checkPostAuthor', $post)
            <button type="button" class="btn btn-danger float-right ml-2" data-toggle="modal"
                data-target="#exampleModal"> Usuń</button>
            <a class="btn btn-secondary float-right" href="/editPost/{{$post->id}}" role="button">Edytuj</a>

            <div class="modal fade " id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-body text-center">
                            <h5 class="text-center">Czy na pewno chcesz usunąć post?</h5>
                            <hr>
                            {{-- <button type="button" class="btn btn-danger" data-dismiss="modal">Tak</button> --}}
                            <a class="btn btn-danger" href="/deletePost/{{$post->id}}" role="button">Tak</a>
                            <button type="button" class="btn btn-primary ml-4" data-dismiss="modal">Nie</button>
                        </div>
                    </div>
                </div>
            </div>
            @endcan
        </div>
    </div>
</div>

<div class="container-fluid comment word-wrap">
    <div class="row justify-content-center">
        <div class="up">
            <span class="post-date-author">
                <img src="/img/clock.png" width="14px" height="14px" class="mr-1 mb-1">
                {{$post->created_at}}
            </span>
        </div>
        <hr class="hr-comment">
        <div class="col-xl-2 col-sm-4 content">
            <img src="../img/anonymous.png" class="userLogo"><br>
            <span class="author">{{App\Models\Post::find($post->id)->user['name']}}</span>
            <span class="user-date">Dołączył/a {{$post->user()->value('created_at')->format('d.m.Y')}}</span>
        </div>
        <div class="col-xl-10 col-sm-8 content text-justify">{{$post->body}}</div>
        <hr class="hr-comment">
    </div>
</div>

@foreach($comments as $comment)
<div class="container-fluid comment">
    <div class="row justify-content-center">
        <div class="up">
            <span class="delEdit">
                @can('checkCommentAuthor', $comment)
                <span class="ml-2 mr-2">
                    <a href="/deleteComment/{{$comment->id}}"> Usuń</a>
                </span>
                <a href="/editComment/{{$comment->id}}">Edytuj</a>
                @endcan
            </span>

            <span class="post-date">
                <img src="/img/clock.png" width="14px" height="14px" class="mr-1 mb-1">
                {{$comment->created_at}}
            </span>
        </div>

        <hr class="hr-comment">
        <div class="col-lg-2 col-md-2 col-sm-2 content">
            <img src="../img/anonymous.png" class="userLogo"><br>
            <span class="author">{{App\Models\Comment::find($comment->id)->user['name']}}</span>
            <span class="user-date">Dołączył/a {{$comment->user()->value('created_at')->format('d.m.Y')}}</span>
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10 content">{{$comment->body}}</div>
        <hr class="hr-comment">
    </div>
</div>
@endforeach

<div class="container-fluid comment p-3 pb-5">
    <form action="/{{$post->id}}" method="POST">
        @csrf
        <div class="form-group">
            <label for="exampleFormControlTextarea1">Dodaj komentarz:</label>
            <textarea class="form-control" name="body" rows="4"></textarea>
            {{ Form::hidden('post_id', $post->id) }}
            @if ((Auth::check()))
            {{ Form::hidden('user_id', Auth::user()->id) }}
            @endif
            <button type="submit" class="btn btn-primary mt-2 float-right">Dodaj</button>
        </div>


    </form>
</div>

@endsection
