@extends('layout')

@section('content')

<div class="row justify-content-center">
    <div class="col-md-4 col-sm-12 mt-5 p-4 bg-light border border-primary">
        <form action="/updatePost/{{$post->id}}" method="POST">
            @csrf
            <a class="btn" href="/{{$post->id}}" role="button">
                <img src="/img/arrow.png" class="navIcon" href="/">
            </a>
            <h3 class="text-center mb-2">Edytuj</h3>

            <div class="mb-3">
                <label>Tytuł posta:</label>
                <input type="text" class="form-control" name="title" placeholder="Dodaj tytuł posta"
                    value="{{$post->title}}">
                @error('title')
                <span class="error">{{$errors->first('title')}}</span>
                @enderror
            </div>

            <div class="form-group ">
                <label>Treść wprowadzenia: </label>
                <textarea class="form-control" name="slug" rows="4"
                    placeholder="Tutaj wpisz zawartość posta">{{$post->slug}}</textarea>
                @error('slug')
                <span class="error">{{$errors->first('slug')}}</span>
                @enderror
            </div>

            <div class="form-group ">
                <label>Treść posta: </label>
                <textarea class="form-control" name="body" rows="7"
                    placeholder="Tutaj wpisz zawartość posta">{{$post->body}}</textarea>
                @error('body')
                <span class="error">{{$errors->first('body')}}</span>
                @enderror
            </div>
            <input type="hidden" name="user_id" value="{{$post->user_id}}">
            <input type="hidden" name="views" value="{{$post->views}}">
            <input type="hidden" name="num_comments" value="{{$post->num_comments}}">
            <button type="submit" name="submit" class="btn btn-success float-center">Edytuj</button>
            <hr>
        </form>
        <a class="btn btn-secondary float-right" href="/" role="button">Zamknij</a>
    </div>
</div>

@endsection
