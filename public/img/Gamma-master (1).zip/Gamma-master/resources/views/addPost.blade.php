@extends('layout')

@section('content')

<div class="row justify-content-center">
    <div class="col-md-8 col-sm-6 mt-5 p-4 bg-light border border-primary">
        <form action="/" method="POST">
            @csrf
            <a class="btn" href="/" role="button">
                <img src="/img/arrow.png" class="navIcon" href="/">
            </a>
            <h3 class="text-center mb-2">Dodaj post:</h3>
            <div class="mb-3">
                <label>Tytuł posta:</label>
                <input type="text" class="form-control" name="title" placeholder="Dodaj tytuł posta" value="{{old('title')}}">
                @error('title')
                    <span class="error">{{$errors->first('title')}}</span>
                @enderror
            </div>

            <div class="form-group ">
                <label>Treść wprowadzenia: </label>
                <textarea class="form-control" name="slug" rows="4" placeholder="Tutaj wpisz wprowadzenie do artykułu">{{old('slug')}}</textarea>
                @error('slug')
                    <span class="error">{{$errors->first('slug')}}</span>
                @enderror
            </div>

            <div class="form-group ">
                <label>Treść posta: </label>
                <textarea class="form-control" name="body" rows="7" placeholder="Tutaj wpisz zawartość posta">{{old('body')}}</textarea>
                @error('body')
                    <span class="error">{{$errors->first('body')}}</span>
                @enderror
            </div>
            <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
            <input type="hidden" name="views" value="0">
            <input type="hidden" name="num_comments" value="0">
            <button type="submit" name="submit" class="btn btn-success">Dodaj</button>
            <hr>
        </form>
        <a class="btn btn-secondary float-right" href="/" role="button">Zamknij</a>
    </div>
</div>

@endsection
