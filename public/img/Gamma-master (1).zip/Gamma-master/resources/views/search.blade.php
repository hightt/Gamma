@extends('layout')
@section('content')
<div class="container-fluid top">
    <div class="row justify-content-center mt-5">

        <div class="col-10">
            <h3>Wyników wyszukiwań: {{$posts->count()}}</h3>
            <a class="btn" href="/" role="button">
                <img src="../img/arrow.png" class="navIcon" href="/posts">
            </a>
        </div>
        <div class="col-2">

        </div>
    </div>
</div>
<div class="container-fluid search">
    <div class="row justify-content-center mt-1">
        <div class="col-12 content">
            <hr class="mt-5 mb-3">
        </div>
    </div>
    @foreach ($posts as $post )
    <div class="row word-wrap ">
        <div class="col-lg-3 col-md-2 content pb-3 ">
            <a href="/{{$post->id}}" class="title">{{$post->title}}</a><br>
            <span class="index-author">
                {{$post->user()->value('name')}}
            </span>
            <span class="index-user-date">{{$post->created_at}}</span>
        </div>
        <div class="col-xl-8 col-md-9 slug">
            {{$post->slug}}
        </div>
        <div class="col-xl-1 col-md-1 content text-right">
            <div class="stat mt-2">
                <img src="../img/view.png" width="20px" height="20px" class="img-spacing"><span
                    class="stats">{{$post->views}}</span> <br>
                <img src="../img/comment.png" width="18px" height="18px" class="img-spacing">
                <span class="stats">
                    {{App\Models\Comment::where('post_id', $post->id)->count()}}
                </span>
            </div>
        </div>
        <div class="col-12">
            <hr class="mt-3 mb-3">
        </div>
    </div>
    @endforeach
</div>
@endsection
