@extends('layout')

@section('content')
<div class="container-fluid top">
    <div class="row justify-content-center mt-5">
        <div class="col-lg-10 col-md-5">
            <h2>Forum</h2>
        </div>
        <div class="col-lg-2 col-md-5">
            <a class="btn btn-primary float-right" href="/add" role="button">Nowy temat</a>
        </div>
    </div>
</div>

<div class="container-fluid post">
    <div class="row justify-content-center mt-1">
        <div class="col-12 content">
            <form action="/" method="get">
                <select class="form-select  float-right post-select mt-4" name="sort" value="Sortuj według"
                    onchange="this.form.submit()">
                    <option selected value="created_at" @if($opt=='created_at' ) selected @endif>Ostatnio opublikowane
                    </option>
                    <option value="views" @if($opt=='views' ) selected @endif>Liczba wyświetleń</option>
                    <option value="num_comments" @if($opt=='num_comments' ) selected @endif>Najczęściej komentowane
                    </option>
                </select><br>
            </form>
            <hr class="mt-5 mb-3">
        </div>
    </div>
    @foreach ($posts as $post )
    <div class="row word-wrap ">
        <div class="col-xl-3 col-sm-3 content pb-3 ">
            <a href="/{{$post->id}}" class="title">{{$post->title}}</a><br>
            <span class="index-author">
                {{$post->user()->value('name')}}
            </span>
            <span class="index-user-date">{{$post->created_at->format('d.m.Y H:i:s')}}</span>
        </div>

        <div class="col-xl-7 col-sm-7 slug">
            {{$post->slug}}
        </div>

        <div class="col-xl-2 col-sm-2 content text-right">
            <div class="stat mt-2">
                <img src="../img/view.png" width="20px" height="20px" class="img-spacing"><span
                    class="stats">{{$post->views}}</span> <br>
                <img src="../img/comment.png" width="18px" height="18px" class="img-spacing">
                <span class="stats">
                    {{$post->comments()->count()}}
                </span>
            </div>
        </div>

        <div class="col-12">
            <hr class="mt-3 mb-3">
        </div>
    </div>
    @endforeach
    <div class="row justify-content-center">
        <div class="col-12">
            {{$posts->links()}}
        </div>
    </div>

</div>


<div class="container-fluid footer mb-3">
    <div class="row justify-content-center mt-5">

        <div class="col-xl-8 col-sm-6">
            <a href="https://www.facebook.com/konrad.duda.167/">
                <img src="/img/facebook.png" class="socialIcon">
            </a>

            <a href="https://www.linkedin.com/in/kd-133422/">
                <img src="/img/linkedin.png" class="socialIcon">
            </a>

            <a href="#">
                <img src="/img/github.png" class="socialIcon">
            </a>
        </div>

        <div class="col-xl-4 col-sm-6 text-right small mt-5">&#169; Copyright Konrad Duda 2021</div>
    </div>
</div>
@endsection
