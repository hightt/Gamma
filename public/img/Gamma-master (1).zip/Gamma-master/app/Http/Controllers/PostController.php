<?php

namespace App\Http\Controllers;
use App\Models\User;
use App\Models\Post;
use App\Models\Comment;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;


class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        $opt = request()->sort;
        if (!isset($opt)) $opt = 'created_at';
        $posts = Post::OrderByDesc($opt)->paginate(15);
        return view('index')->with(compact('posts'))->with(compact('opt'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::check()) return view('addPost');
        else return redirect('login');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Post::create($this->validateForm());
        return redirect('/');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post, Comment $comment)
    {
        $comments = Comment::where('post_id', $post->id)->get();
        $post->increment('views', 1);
        return view('show')->with(compact('post'))->with(compact('comments'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {
        return view('editPost', compact('post'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(Post $post)
    {
        $post->update($this->validateForm());
        return redirect('/' . $post->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function destroy(Post $post)
    {
        $post->delete();
        return redirect('/');
    }

    public function search(Request $request)
    {
        $posts = Post::where('title', 'LIKE',  "%" . $request->search . "%")->get();
        return view('search', compact('posts'));
    }
    protected function validateForm()
    {
        return request()->validate([
            'user_id' => 'required',
            'title' => 'required|min:3|max:100',
            'slug' => 'required|min:3|max:300',
            'body' => 'required|min:3',
            'views' => 'required',
            'num_comments' => 'required'
        ]);
    }
}
