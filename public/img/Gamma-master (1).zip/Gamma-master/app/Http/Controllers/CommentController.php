<?php

namespace App\Http\Controllers;
use App\Models\Post;
use App\Models\Comment;
use Illuminate\Http\Request;

class CommentController extends Controller
{
    public function store(Post $post, Request $request)
    {
        Comment::create($this->validateForm());
        $post->increment('num_comments', 1);
        return redirect('/'.$request->post_id);
    }

    public function destroy(Post $post, Comment $comment)
    {
        $this->authorize('checkCommentAuthor', $comment);
        $comment->delete();
        $post->where('id', $comment->post_id)->decrement('num_comments', 1);
        return redirect('/'.$comment->post_id);

    }

    public function edit(Comment $comment)
    {
        $this->authorize('checkCommentAuthor', $comment);
        return view('editComment', compact('comment'));
    }

    public function update(Comment $comment)
    {
        $this->authorize('checkCommentAuthor', $comment);
        $comment->update($this->validateForm());
        return redirect('/'. $comment->post()->value('id'));
    }

    protected function validateForm()
    {
        return request()->validate([
            'user_id' => 'required',
            'post_id' => 'required',
            'body' => 'required|min:3',
        ]);
    }
}
