<?php

namespace App\Policies;
use App\Models\User;
use App\Models\Post;
use App\Models\Comment;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Support\Facades\Auth;
class PostPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Post  $post
     * @return mixed
     */
    public function checkPostAuthor(User $user, Post $post)
    {
        if($user->name == 'admin') return 'true';
        else return $post->user()->is($user);
    }


}
