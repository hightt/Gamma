<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\PostController;
use App\Http\Controllers\CommentController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Auth::routes();

Route::get('/', [PostController::class, 'index'])->name('home');
Route::post('/', [PostController::class, 'store']);

Route::get('/add', [PostController::class, 'create']);
Route::get('/logout', '\App\Http\Controllers\Auth\LoginController@logout');
Route::post('/search', [PostController::class, 'search']);

Route::get('/{post}', [PostController::class, 'show']);
Route::post('/{post}', [CommentController::class, 'store']);

Route::get('/editPost/{post}', [PostController::class, 'edit'])->middleware('can:checkPostAuthor,post');
Route::post('/updatePost/{post}', [PostController::class, 'update'])->middleware('can:checkPostAuthor,post');
Route::get('/deletePost/{post}', [PostController::class, 'destroy'])->middleware('can:checkPostAuthor,post');

Route::get('/editComment/{comment}', [CommentController::class, 'edit'])->middleware('can:checkCommentAuthor,comment');
Route::post('/updateComment/{comment}', [CommentController::class, 'update'])->middleware('can:checkCommentAuthor,comment');
Route::get('/deleteComment/{comment}', [CommentController::class, 'destroy'])->middleware('can:checkCommentAuthor,comment');









